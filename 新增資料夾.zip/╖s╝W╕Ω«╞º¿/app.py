from flask import Flask, request, render_template
import sqlite3, bcrypt

app = Flask(__name__)

# -----------------------------
# 建立資料庫
# -----------------------------
conn = sqlite3.connect('database.db', check_same_thread=False)
c = conn.cursor()
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    email TEXT UNIQUE,
    password TEXT
)
''')
conn.commit()

# -----------------------------
# 註冊頁面
# -----------------------------
@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    confirm = request.form.get('confirmPassword')

    if not all([username, email, password, confirm]):
        return "請填寫所有欄位"
    if password != confirm:
        return "密碼與確認密碼不一致"
    if len(password) < 8:
        return "密碼至少 8 字"

    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    c = conn.cursor()  # 每次請求重新拿 cursor
    try:
        c.execute("INSERT INTO users (username,email,password) VALUES (?,?,?)",
                  (username,email,hashed))
        conn.commit()
    except sqlite3.IntegrityError:
        return "Email 已被註冊"

    return "註冊成功 ✅"

# -----------------------------
# 後台查看使用者
# -----------------------------
@app.route('/admin')
def admin():
    c = conn.cursor()
    c.execute("SELECT id, username, email FROM users")
    users = c.fetchall()
    html = "<h2>後台管理</h2><p>總註冊人數：{}</p><table border=1>".format(len(users))
    html += "<tr><th>ID</th><th>使用者名稱</th><th>Email</th></tr>"
    for u in users:
        html += "<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(u[0], u[1], u[2])
    html += "</table>"
    return html

if __name__ == '__main__':
    app.run(debug=True)
